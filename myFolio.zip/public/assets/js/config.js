export const testimonials = [
  {
    name: "10i",
    avatar: "/public/assets/img/avatars/10i.png",
    profile: "",
    review: "uhh"
  },
    {
    name: "EpicE",
    avatar: "/public/assets/img/avatars/epice.png",
    profile: "",
    review: "testfrfrfr"
  }
]
export const works = [
  {
    title: "cdn",
    description: "A Normal CDN",
    image: "",
    filter: "web",
    buttons: [
      {
        text: "View Repo",
        link: "https://github.com/iconicayansh-dev/cdn"
      }
    ]
  },
  {
    title: "Cats Hub",
    description: "A Discord server related to cats",
    image: "https://cdn.discordapp.com/icons/945227072492691537/a_616e02a7a04f4e1ca577f9df7cbcc2cf.gif?size=2048",
    filter: "discord",
    buttons: [
      {
        text: "Join",
        link: "https://discord.gg/ecats"
      }
    ]
  },
  {
    title: "Portfolio",
    description: "A better forked version of https://github.com/VaibhavAswal/myFolio in HTML",
    image: "",
    filter: "web",
    buttons: [
      {
        text: "Visit",
        link: "https://ayansh.xyz/"
      },
      {
        text: "Original",
        link: "https://github.com/VaibhavAswal/myFolio"
      }
    ]
  }
]